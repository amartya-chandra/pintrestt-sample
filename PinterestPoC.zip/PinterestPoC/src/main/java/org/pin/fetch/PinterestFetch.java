package org.pin.fetch;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.pin.entity.Pin;
import org.pin.entity.User;
import org.pin.util.Utils;

import au.com.bytecode.opencsv.CSVReader;

/**
 * Retrieves information about a given user from Pinterest
 */
@SuppressWarnings("unused")
public class PinterestFetch {

	private String baseUrl = "https://api.pinterest.com/v1/users/";
	public static final String accessTokenParam = "/?access_token=";
	public static final String accessToken = "REPLACE_YOUR_TOKEN";
	private String userName;

	/**
	 * 
	 * @param userName
	 */
	public PinterestFetch(String userName) {

		this.userName = userName.trim();
	}

	/**
	 * 
	 * @param userName
	 * @return
	 */
	private String getFullLink(String userName) {

		String url = this.baseUrl + userName.trim() + accessTokenParam + accessToken;
		return url;
	}

	/**
	 * 
	 * @return
	 */
	private String getFullLink() {

		String url = this.baseUrl + this.userName.trim() + accessTokenParam + accessToken;
		return url;
	}

	/**
	 * 
	 * @return
	 */
	private User getUserInfo() {

		User pinUser = null;
		String url = getFullLink();
		try {
			String jsonResponse = Utils.getPageResponse(url);
			JSONObject response = Utils.getJSONPage(jsonResponse);
			pinUser = populateUserInfo(pinUser, response);
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}

		return pinUser;
	}

	/**
	 * 
	 * @param userName
	 * @return
	 */
	private User getUserInfo(String userName) {

		User pinUser = null;
		String url = getFullLink(userName);
		try {
			String jsonResponse = Utils.getPageResponse(url);
			JSONObject response = Utils.getJSONPage(jsonResponse);
			pinUser = populateUserInfo(pinUser, response);
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}

		return pinUser;
	}

	/**
	 * 
	 * @param user
	 * @param json
	 * @return
	 */
	private User populateUserInfo(User user, JSONObject json) {

		if (user == null) {
			user = new User();
		}

		JSONObject data = (JSONObject) json.get("data");

		user.setUrl((String) data.get("url"));
		user.setId((String) data.get("id"));
		user.setFirstName((String) data.get("first_name"));
		user.setLastName((String) data.get("last_name"));

		return user;
	}

	public String createBoard(String name, String url) {
		JSONObject boardParams = new JSONObject();
		boardParams.put("name", name);
		boardParams.put("description", "Programatically Created");
		String response = "";
		try {
			response = Utils.postJsonData(boardParams.toJSONString(), url);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;
	}

	public void createPins(String boardId, String fileName, String pinUrl) {
		CSVReader reader = null;
		try {
			reader = new CSVReader(new FileReader(fileName), ',', '"', 1);
			String nextLine[] = null;
			while ((nextLine = reader.readNext()) != null) {
				if (nextLine != null) {
					// Verifying the read data here
					// System.out.println(Arrays.toString(nextLine));

					JSONObject pinParams = new JSONObject();
					// pinParams.put("board", "540713567700759966");
					pinParams.put("board", boardId);
					pinParams.put("fields", "attribution,board,color,counts,created_at,creator,image,link,media,metadata,note,original_link,url");
					pinParams.put("link", nextLine[0]);
					pinParams.put("note", nextLine[1]);
					pinParams.put("image_url", nextLine[2]);
					pinParams.put("title", nextLine[1]);
					pinParams.put("type", "Product");
					pinParams.put("description", "");
					pinParams.put("url", nextLine[0]);
					pinParams.put("site_name", "www.amazon.com");
					pinParams.put("price", nextLine[3]);
					pinParams.put("currency_code", "USD");
					
					Map<String,String> metaDataMap = new HashMap<String,String>();
					metaDataMap.put("title", nextLine[1]);
					metaDataMap.put("type", "Product");
					metaDataMap.put("description", "");
					metaDataMap.put("url", nextLine[0]);
					metaDataMap.put("price", nextLine[3]);					
					metaDataMap.put("currency_code", "USD");					
					metaDataMap.put("site_name", "www.amazon.com");				
					metaDataMap.put("og:title", nextLine[1]);
					metaDataMap.put("og:type", "Product");
					metaDataMap.put("og:description", "");
					metaDataMap.put("og:url", nextLine[0]);
					metaDataMap.put("og:site_name", "www.amazon.com");
					metaDataMap.put("product:price:amount", nextLine[3]);
					metaDataMap.put("product:price:currency", "USD");
					pinParams.put("metadata", metaDataMap);
					
					String pinResponse = "";
					try {
						pinResponse = Utils.postJsonData(pinParams.toJSONString(), pinUrl);
						System.out.println("The response data is " + pinResponse);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@SuppressWarnings("unchecked")
	public static void main(String str[]) {
		PinterestFetch fetch = new PinterestFetch("dhayanidhirajas");
		System.out.println(fetch.getUserInfo());
		BoardFetch board = new BoardFetch();
		List<Pin> boardPins = board.boardProcessingPipeline();
		for (Pin pin : boardPins) {
			System.out.println(pin);
		}

		String boardUrl = "https://api.pinterest.com/v1/boards" + accessTokenParam + accessToken;
		String boards[] = { "LG", "Motorola", "Samsung" };
		//String boards[] = { "Samsung" };
		for (int i = 0; i < boards.length; i++) {
			//String response = fetch.createBoard(boards[i], boardUrl);
			//System.out.println("The response is " + response);
		}

		String pinUrl = "https://api.pinterest.com/v1/pins" + accessTokenParam + accessToken;
		 String boardIds[] = { "540713567700777478", "540713567700777479",
		 "540713567700777480" };
		//String boardIds[] = { "540713567700765484" };
		String fileNames[] = { "E:/Projects/Pinterest/AmazonLGProducts.csv",
				"E:/Projects/Pinterest/AmazonMotorolaProducts.csv", "E:/Projects/Pinterest/AmazonSamsungProducts.csv" };
				
		//String fileNames[] = {"E:/Projects/Pinterest/AmazonSamsungProducts2.csv" };
		for (int i = 0; i < fileNames.length; i++) {
			fetch.createPins(boardIds[i], fileNames[i], pinUrl);
		}
	}
}
