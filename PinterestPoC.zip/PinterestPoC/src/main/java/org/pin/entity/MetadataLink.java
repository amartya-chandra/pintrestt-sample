package org.pin.entity;

public class MetadataLink {
	
	private String favicon;
	private String title;
	private String locale;
	private String description;
	private String siteName;
	
	/**
	 * @return the favicon
	 */
	public String getFavicon() {
		return favicon;
	}
	/**
	 * @param favicon the favicon to set
	 */
	public void setFavicon(String favicon) {
		this.favicon = favicon;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the locale
	 */
	public String getLocale() {
		return locale;
	}
	/**
	 * @param locale the locale to set
	 */
	public void setLocale(String locale) {
		this.locale = locale;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the siteName
	 */
	public String getSiteName() {
		return siteName;
	}
	/**
	 * @param siteName the siteName to set
	 */
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MetadataLink [favicon=" + favicon + ", title=" + title
				+ ", locale=" + locale + ", description=" + description
				+ ", siteName=" + siteName + "]";
	}
}
