package org.pin.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Defines a set of utility functions to used frequently
 */
public class Utils {

	/**
	 * Given a JSON response in form of a string converts it into a JSON Object
	 * 
	 * @param page
	 *            String containing the JSON response
	 * @return JSON Object containing the response
	 * @throws ParseException
	 */
	public static JSONObject getJSONPage(String page) throws ParseException {

		JSONParser parser = new JSONParser();
		JSONObject jsonPage = (JSONObject) parser.parse(page);

		return jsonPage;

	}

	/**
	 * Given a url opens it and returns a String containing the response
	 * 
	 * @param url
	 *            String containing the unique url
	 * @return String containing the contents of the given url
	 * @throws IOException
	 */
	public static String getPageResponse(String url) throws IOException {

		StringBuilder page = new StringBuilder("");
		String temp = "";
		URL link = new URL(url);
		BufferedReader br = new BufferedReader(new InputStreamReader(link.openStream()));

		while ((temp = br.readLine()) != null) {

			page = page.append(temp);
		}

		return page.toString();
	}

	/**
	 * Converts a comma separated string to a list
	 * 
	 * @param s
	 *            String containing the comma separated values
	 * @return List<String> containing the contents of the string
	 */
	public static List<String> convertCsvToList(String s) {

		List<String> stringList = new ArrayList<String>();
		String[] values = s.split(",");
		for (String val : values) {
			stringList.add(val.trim());
		}

		return stringList;
	}

	/**
	 * Converts a comma separated String into a set
	 * 
	 * @param s
	 *            String containing the comma separated values
	 * @return Set<String> containing the values
	 */
	public static Set<String> convertCsvToSet(String s) {

		List<String> stringList = convertCsvToList(s);
		Set<String> set = new HashSet<String>();
		for (String list : stringList) {
			set.add(list);
		}

		return set;
	}

	/**
	 * Converts a JSONArray into a list of Strings
	 * 
	 * @param array
	 *            JSONArray which is to be converted
	 * @return List<String> containing the contents of the JSONArray
	 */
	public static List<String> convertJSONArrayToList(JSONArray array) {

		List<String> list = new ArrayList<String>();
		for (int i = 0; i < array.size(); i++) {
			list.add((String) array.get(i));
		}

		return list;
	}

	public static String postJsonData(String jsonData, String url) throws Exception {
		final HttpClient httpClient = new HttpClient();
		StringRequestEntity requestEntity = new StringRequestEntity(jsonData, "application/json", "UTF-8");
		PostMethod postMethod = new PostMethod(url);
		postMethod.setRequestEntity(requestEntity);
		httpClient.executeMethod(postMethod);
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(postMethod.getResponseBodyAsStream(), "UTF-8"));
		String line = null;
		StringBuilder response = new StringBuilder();
		while ((line = reader.readLine()) != null) {
			response.append(line).append(System.getProperty("line.separator"));
		}
		reader.close();
		postMethod.releaseConnection();
		return response.toString();
	}

	public static String getRawJson(String url) {
		URL theUrl;
		try {
			theUrl = new URL(url);
			InputStream response;
			response = theUrl.openStream();
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(response));
			List<String> rawJson = new ArrayList<String>();

			for (String line; (line = bufferedReader.readLine()) != null;) {
				rawJson.add(line);
			}

			bufferedReader.close();

			return rawJson.get(0);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

}
