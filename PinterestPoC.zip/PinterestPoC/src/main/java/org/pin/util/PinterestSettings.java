package org.pin.util;

public class PinterestSettings {
	// Enter your settings in this class
	// Register for an API key: http://pinterest.com/developers/applications/new/
	
	private static String ApplicationId = "4935009376296515580";
	public static String getApplicationId() {
		return ApplicationId;
	}
	
	private static String ClientSecret = "51692bc8cf1a24686a154173222701ab9ef4028d5be0bfaf1445e62f7f962a2e";
	public static String getClientSecret() {
		return ClientSecret;
	}
	
	private static String CallbackUrl = "http://facebook.com";
	public static String getCallbackUrl() {
		return CallbackUrl;
	}
	
	private static String BaseUrl = "https://api.pinterest.com/v2/";
	public static String getBaseUrl() {
		return BaseUrl;
	}
	
	private static String PopularEndpointUrl = "popular/";
	public static String getPopularEndpointUrl() {
		return PopularEndpointUrl;
	}

	private static String UserEndpointUrl = "users/%s/";
	public static String getUserEndpointUrl() {
		return UserEndpointUrl;
	}
}
